const express = require('express');
const bodyParser = require('body-parser');
const bookingRoutes = require('./routes/bookings');
const path = require('path');

const app = express();

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');

// Routes
app.use('/', bookingRoutes);

app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});
