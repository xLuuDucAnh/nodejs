const express = require('express');
const router = express.Router();
const db = require('../models/Booking');

// Trang danh sách đặt chỗ
router.get('/', (req, res) => {
    db.query('SELECT * FROM Bookings', (err, results) => {
        if (err) throw err;
        res.render('bookingList', { bookings: results });
    });
});

// Trang thêm đặt chỗ mới
router.get('/new', (req, res) => {
    res.render('bookingForm');
});

router.post('/new', (req, res) => {
    const { customerName, date, time } = req.body;
    db.query(
        'INSERT INTO Bookings (customerName, date, time) VALUES (?, ?, ?)',
        [customerName, date, time],
        (err) => {
            if (err) throw err;
            res.redirect('/');
        }
    );
});

// Trang sửa đặt chỗ
router.get('/edit/:id', (req, res) => {
    const { id } = req.params;
    db.query('SELECT * FROM Bookings WHERE id = ?', [id], (err, results) => {
        if (err) throw err;
        res.render('editBooking', { booking: results[0] });
    });
});

router.post('/edit/:id', (req, res) => {
    const { id } = req.params;
    const { customerName, date, time } = req.body;
    db.query(
        'UPDATE Bookings SET customerName = ?, date = ?, time = ? WHERE id = ?',
        [customerName, date, time, id],
        (err) => {
            if (err) throw err;
            res.redirect('/');
        }
    );
});

// Hủy đặt chỗ
router.post('/cancel/:id', (req, res) => {
    const { id } = req.params;
    db.query(
        'UPDATE Bookings SET status = "Cancelled" WHERE id = ?',
        [id],
        (err) => {
            if (err) throw err;
            res.redirect('/');
        }
    );
});

module.exports = router;
