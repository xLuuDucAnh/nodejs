router.get('/', (req, res) => {
    db.query('SELECT * FROM Bookings', (err, results) => {
        if (err) throw err;
        res.render('bookingList', { bookings: results });
    });
});
